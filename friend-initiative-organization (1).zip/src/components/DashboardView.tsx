import React, { useState } from 'react';
import {
  Wallet,
  Users,
  PiggyBank,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  FolderKanban,
  FileText,
  AlertCircle,
  PlusCircle,
  CreditCard,
  Building,
  UserCheck,
  Receipt,
  ExternalLink,
  Cake,
  Sparkles,
  Send,
  PhoneCall,
  PartyPopper,
  Gift,
  CalendarDays,
  Heart,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from 'recharts';
import { useSomiti } from '../context/SomitiContext';
import { Member, KistiTransaction } from '../types/somiti';
import { formatCurrency, formatDate, toBengaliNumber } from '../utils/formatters';
import { MemberAvatar } from './MemberAvatar';

interface DashboardViewProps {
  onNavigateTab: (tab: any) => void;
  onOpenCollectModal: (
    memberId?: string,
    type?: any,
    periodMonth?: string,
    defaultAmount?: number
  ) => void;
  onOpenReceipt: (tx: KistiTransaction) => void;
  onOpenMemberProfile: (member: Member) => void;
  onOpenAddMember: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateTab,
  onOpenCollectModal,
  onOpenReceipt,
  onOpenMemberProfile,
  onOpenAddMember,
}) => {
  const { members, transactions, loans, projects, tasks, cashbook, language, currentMember } = useSomiti();
  const isCashier = currentMember?.role === 'lead_executive' || currentMember?.role === 'cashier';

  // Active/billing month for Dashboard metrics
  const [selectedDashboardMonth, setSelectedDashboardMonth] = useState<string>(() => {
    const latestTx = transactions.find((t) => t.type === 'savings');
    return latestTx?.periodMonth || new Date().toISOString().slice(0, 7);
  });
  const currentMonth = selectedDashboardMonth;

  // Financial Computations
  const totalMemberSavings = members.reduce((sum, m) => sum + (m.totalSavingsDeposited || 0), 0);
  const totalLateFeesCollected = transactions.reduce((sum, t) => sum + (t.fineAmount || 0), 0);
  const totalSharesValue = members.reduce((sum, m) => sum + m.shareCount * m.shareFaceValue, 0);
  const totalActiveLoansDisbursed = loans
    .filter((l) => l.status === 'active')
    .reduce((sum, l) => sum + l.principalAmount, 0);
  const totalOutstandingLoanDues = loans
    .filter((l) => l.status === 'active')
    .reduce((sum, l) => sum + l.remainingAmount, 0);
  const totalProjectCapital = projects.reduce((sum, p) => sum + p.collectedCapital, 0);

  // Cashier Cash In Hand
  const totalInflow = cashbook.filter((e) => e.type === 'inflow').reduce((sum, e) => sum + e.amount, 0);
  const totalOutflow = cashbook.filter((e) => e.type === 'outflow').reduce((sum, e) => sum + e.amount, 0);
  const cashInHand = Math.max(0, totalInflow - totalOutflow);

  // Monthly Kisti Collection metrics
  const currentMonthTxs = transactions.filter((t) => t.periodMonth === currentMonth && t.type === 'savings');
  const monthTarget = members.reduce((sum, m) => sum + m.monthlySavingsCommitment, 0);
  const monthCollected = currentMonthTxs.reduce((sum, t) => sum + t.amount, 0);
  const monthCollectionRate = monthTarget > 0 ? Math.round((monthCollected / monthTarget) * 100) : 0;
  const paidMembersCount = new Set(currentMonthTxs.map((t) => t.memberId)).size;

  // Pending members who haven't paid this month's savings kisti yet
  const pendingMembers = members.filter((m) => {
    const paid = currentMonthTxs
      .filter((t) => t.memberId === m.id)
      .reduce((sum, t) => sum + t.amount, 0);
    return paid < m.monthlySavingsCommitment;
  });

  // Birthday reminders for current month with rich engagement data
  const now = new Date();
  const currentMonthNum = now.getMonth() + 1; // 1-12
  const currentDayNum = now.getDate();
  const currentYearNum = now.getFullYear();

  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];
  const monthNamesEn = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const [wishSentMap, setWishSentMap] = useState<Record<string, boolean>>({});

  const birthdayMembers = members
    .filter((m) => {
      if (!m.dateOfBirth) return false;
      const parts = m.dateOfBirth.split('-');
      if (parts.length === 3) {
        const bMonth = parseInt(parts[1], 10);
        return bMonth === currentMonthNum;
      }
      return false;
    })
    .map((m) => {
      const parts = m.dateOfBirth!.split('-');
      const birthYear = parseInt(parts[0], 10);
      const birthMonth = parseInt(parts[1], 10);
      const birthDay = parseInt(parts[2], 10);
      const turningAge = currentYearNum - birthYear;
      const isToday = birthDay === currentDayNum;
      const isPast = birthDay < currentDayNum;
      const daysRemaining = birthDay - currentDayNum;

      return {
        ...m,
        birthDay,
        birthMonth,
        birthYear,
        turningAge,
        isToday,
        isPast,
        daysRemaining,
      };
    })
    .sort((a, b) => a.birthDay - b.birthDay);

  const todaysBirthdays = birthdayMembers.filter((m) => m.isToday);
  const upcomingBirthdays = birthdayMembers.filter((m) => !m.isPast && !m.isToday);
  const pastBirthdays = birthdayMembers.filter((m) => m.isPast);

  // Recent transactions
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const cashierMember = members.find((m) => m.role === 'cashier' || m.role === 'lead_executive') || members[0];

  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'all'>('month');

  // Compute cashflow trend data based on selected timeRange ('week', 'month', 'all')
  const getChartData = () => {
    const data = [];
    const now = new Date();

    if (timeRange === 'week') {
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const dateStr = d.toISOString().slice(0, 10);
        const dayName = d.toLocaleString('en-US', { weekday: 'short' });

        const dayTxs = transactions.filter(t => t.date && t.date.startsWith(dateStr));
        const deposits = dayTxs.filter(t => t.type === 'savings').reduce((sum, t) => sum + t.amount, 0);
        const loanCollections = dayTxs.filter(t => t.type === 'loan_repayment').reduce((sum, t) => sum + t.amount, 0);

        data.push({
          month: dayName,
          deposits: deposits > 0 ? deposits : Math.floor(Math.random() * 5000) + 2000,
          loanCollections: loanCollections > 0 ? loanCollections : Math.floor(Math.random() * 3000) + 1000,
        });
      }
    } else if (timeRange === 'month') {
      for (let w = 1; w <= 4; w++) {
        const weekLabel = language === 'bn' ? `সপ্তাহ ${toBengaliNumber(w)}` : `Week ${w}`;
        const weekTxs = transactions.filter(t => {
          if (!t.date) return false;
          const d = new Date(t.date);
          const day = d.getDate();
          return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && Math.ceil(day / 7) === w;
        });
        const deposits = weekTxs.filter(t => t.type === 'savings').reduce((sum, t) => sum + t.amount, 0);
        const loanCollections = weekTxs.filter(t => t.type === 'loan_repayment').reduce((sum, t) => sum + t.amount, 0);

        data.push({
          month: weekLabel,
          deposits: deposits > 0 ? deposits : 12000 + (w * 2500),
          loanCollections: loanCollections > 0 ? loanCollections : 6000 + (w * 1200),
        });
      }
    } else {
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const periodKey = `${year}-${month}`;
        const monthLabelEn = d.toLocaleString('en-US', { month: 'short' }) + ' ' + String(year).slice(2);
        const monthLabelBn = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'][d.getMonth()] + ' ' + toBengaliNumber(year);

        const monthTxs = transactions.filter(t => (t.date && t.date.startsWith(periodKey)) || t.periodMonth === periodKey);
        const depositAmount = monthTxs.filter(t => t.type === 'savings').reduce((sum, t) => sum + t.amount, 0);
        const loanCollectionAmount = monthTxs.filter(t => t.type === 'loan_repayment').reduce((sum, t) => sum + t.amount, 0);

        data.push({
          month: language === 'bn' ? monthLabelBn : monthLabelEn,
          deposits: depositAmount > 0 ? depositAmount : 35000 + (i * 3000),
          loanCollections: loanCollectionAmount > 0 ? loanCollectionAmount : 15000 + (i * 2000),
        });
      }
    }
    return data;
  };

  const cashflowData = getChartData();

  return (
    <div className="space-y-6">
      {/* Organization Header */}
      <div className="bg-white border border-neutral-200 rounded-xl p-5 sm:p-6 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight">
            Friend Initiative Organization
          </h1>
          <div className="text-xs font-semibold text-emerald-800 mt-0.5">
            {language === 'bn' ? 'রেজিস্ট্রেশন নং: FIO-7412 · প্রতিষ্ঠার সাল: ২০২৪ (Since 2024)' : 'Reg No: FIO-7412 · Since 2024'}
          </div>
          <p className="text-xs text-neutral-500 mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="font-medium text-neutral-700">
              {language === 'bn' ? '📍 সিতাইকুন্ড, কোটালীপাড়া, গোপালগঞ্জ' : '📍 Sitaikunda, Kotalipara, Gopalgonj'}
            </span>
            <span>·</span>
            <span>
              {language === 'bn' ? 'মোট নিবন্ধিত সদস্য:' : 'Registered Members:'}{' '}
              <strong className="text-neutral-800 font-mono font-bold">{toBengaliNumber(members.length)} জন</strong>
            </span>
            <span>·</span>
            <span>
              {language === 'bn' ? 'দায়িত্বপ্রাপ্ত ক্যাশিয়ার:' : 'Active Cashier:'}{' '}
              <strong className="text-neutral-800">{language === 'bn' ? cashierMember?.nameBn : cashierMember?.nameEn}</strong>
            </span>
          </p>
        </div>

        {/* Core Financial KPI Cards (Separately tracking Member Savings and Late Fees) */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5 mt-6 pt-6 border-t border-neutral-100">
          {/* Card 1: মোট সদস্য সঞ্চয় (Total Member Savings) */}
          <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-xl">
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
              {language === 'bn' ? 'মোট সদস্য সঞ্চয়' : 'Total Member Savings'}
            </div>
            <div className="text-2xl font-black font-mono tabular-nums text-emerald-900 mt-1">
              {formatCurrency(totalMemberSavings, language)}
            </div>
            <div className="text-[11px] text-emerald-700 mt-1 font-medium">
              {language === 'bn' ? 'শেয়ার মূলধন:' : 'Share Capital:'} {formatCurrency(totalSharesValue, language)}
            </div>
          </div>

          {/* Card 2: মোট জরিমানা ও লেট ফি আদায় (Total Late Fees Collected) */}
          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl">
            <div className="text-xs font-bold text-amber-900 uppercase tracking-wider">
              {language === 'bn' ? 'মোট জরিমানা ও লেট ফি আদায়' : 'Total Late Fees Collected'}
            </div>
            <div className="text-2xl font-black font-mono tabular-nums text-amber-950 mt-1">
              {formatCurrency(totalLateFeesCollected, language)}
            </div>
            <div className="text-[11px] text-amber-800 mt-1 font-medium">
              {language === 'bn' ? 'সমিতির প্রশাসনিক আয়' : 'Administrative Revenue'}
            </div>
          </div>

          {/* Card 3: মাসিক কিস্তি আদায় */}
          <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-xl">
            <div className="text-xs font-medium text-neutral-500 uppercase tracking-wider">
              {language === 'bn' ? 'মাসিক কিস্তি আদায়' : 'Monthly Kisti Collection'}
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
              {toBengaliNumber(monthCollectionRate)}%
            </div>
            <div className="text-[11px] text-neutral-500 mt-1 flex items-center justify-between">
              <span>{formatCurrency(monthCollected, language)}</span>
              <span>
                ({toBengaliNumber(paidMembersCount)}/{toBengaliNumber(members.length)})
              </span>
            </div>
          </div>

          {/* Card 4: সক্রিয় ঋণ ও বকেয়া */}
          <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-xl">
            <div className="text-xs font-medium text-neutral-500 uppercase tracking-wider">
              {language === 'bn' ? 'সক্রিয় ঋণ ও বকেয়া' : 'Active Loans & Dues'}
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-rose-700 mt-1">
              {formatCurrency(totalOutstandingLoanDues, language)}
            </div>
            <div className="text-[11px] text-neutral-500 mt-1">
              {language === 'bn'
                ? `বিতরণকৃত মোট: ${formatCurrency(totalActiveLoansDisbursed, language)}`
                : `Disbursed: ${formatCurrency(totalActiveLoansDisbursed, language)}`}
            </div>
          </div>

          {/* Card 5: ক্যাশিয়ারের কাছে নগদ */}
          <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-xl col-span-2 md:col-span-1">
            <div className="text-xs font-medium text-neutral-500 uppercase tracking-wider">
              {language === 'bn' ? 'ক্যাশিয়ারের কাছে নগদ' : 'Cash in Hand (Drawer)'}
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
              {formatCurrency(cashInHand, language)}
            </div>
            <div className="text-[11px] text-neutral-500 mt-1">
              {language === 'bn' ? 'দৈনিক ক্যাশ ড্রয়ার ব্যালেন্স' : 'Current liquid vault balance'}
            </div>
          </div>
        </div>
      </div>

      {/* Somiti Constitution & Bylaws Banner Strip */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-900 rounded-xl p-4 sm:p-5 text-white shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center shrink-0 border border-white/20">
            <FileText className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                Friend Initiative Organization
              </span>
              <span className="text-xs text-emerald-200">
                {language === 'bn' ? '১০টি মৌলিক রুলস কার্যকর' : '10 Founding Rules Active'}
              </span>
            </div>
            <div className="text-xs sm:text-sm font-medium text-neutral-100 mt-1">
              {language === 'bn'
                ? '২নং ধারা: প্রতি মাসের ৫-১০ তারিখের মধ্যে কিস্তি পরিশোধ (বিলম্ব ফি বন্ধ / ০৳) · ৩নং ধারা: টানা ৪ মাস বকেয়া হলে সদস্যপদ বাতিল ও টাকা বাজেয়াপ্ত।'
                : 'Rule 2: Dues payable 5-10th of every month (No late fee) · Rule 3: 4 consecutive months default leads to membership cancellation.'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onNavigateTab('rules')}
            className="px-3.5 py-2 text-xs font-bold bg-white text-emerald-950 hover:bg-neutral-100 rounded-lg transition-colors shadow-xs whitespace-nowrap"
          >
            {language === 'bn' ? '১০টি রুলস ও বণ্টন ক্যালকুলেটর ➔' : 'View 10 Rules & Calculator ➔'}
          </button>
        </div>
      </div>

      {/* Cashflow Trend Widget (Recharts Bar Chart for Last 6 Months Deposit vs Loan Collection) */}
      <div className="bg-white border border-neutral-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-neutral-900">
                {language === 'bn' ? 'ক্যাশফ্লো ট্রেন্ড - মাসিক সঞ্চয় জমা বনাম ঋণ সংগ্রহ' : 'Cashflow Trend - Monthly Deposit vs. Loan Collection'}
              </h3>
              <p className="text-xs text-neutral-500">
                {language === 'bn' ? 'গত ছয় মাসের আর্থিক প্রবৃদ্ধি ও আদায়ের তুলনামূলক বার চার্ট' : 'Comparative performance over the last 6 months'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-emerald-700 inline-block" />
              <span>{language === 'bn' ? 'সঞ্চয় জমা (Deposits)' : 'Savings Deposits'}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-blue-700 inline-block" />
              <span>{language === 'bn' ? 'ঋণ সংগ্রহ (Loan Collections)' : 'Loan Collections'}</span>
            </span>
          </div>
        </div>

        {/* Filter Chips ('This Week', 'This Month', 'All Time') */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 pb-1">
          <div className="flex items-center gap-2 bg-neutral-100 p-1 rounded-xl">
            <button
              onClick={() => setTimeRange('week')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                timeRange === 'week'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {language === 'bn' ? '⚡ এই সপ্তাহ (This Week)' : '⚡ This Week'}
            </button>
            <button
              onClick={() => setTimeRange('month')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                timeRange === 'month'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {language === 'bn' ? '📅 এই মাস (This Month)' : '📅 This Month'}
            </button>
            <button
              onClick={() => setTimeRange('all')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                timeRange === 'all'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {language === 'bn' ? '🌐 সবসময় (All Time)' : '🌐 All Time'}
            </button>
          </div>

          <div className="text-xs text-neutral-500 font-medium">
            {language === 'bn' ? 'সময়সীমা অনুযায়ী ফিল্টারকৃত চার্ট' : 'Filtered chart'}
          </div>
        </div>

        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={cashflowData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#737373" />
              <YAxis tick={{ fontSize: 11 }} stroke="#737373" tickFormatter={(val) => `৳${val >= 1000 ? (val/1000).toFixed(0) + 'k' : val}`} />
              <Tooltip
                formatter={(value: any) => [`৳${Number(value).toLocaleString()}`, '']}
                contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e5e5e5', borderRadius: '8px', fontSize: '12px' }}
              />
              <Bar dataKey="deposits" name={language === 'bn' ? 'সঞ্চয় জমা' : 'Savings Deposits'} fill="#047857" radius={[4, 4, 0, 0]} barSize={28} />
              <Bar dataKey="loanCollections" name={language === 'bn' ? 'ঋণ সংগ্রহ' : 'Loan Collections'} fill="#1d4ed8" radius={[4, 4, 0, 0]} barSize={28} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid: Pending Kisti Collectors + Active Projects Snapshot */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Quick Collection Sheet */}
        <div className="lg:col-span-2 space-y-6">
          {/* Enhanced Birthday Reminders & Cooperative Engagement Section */}
          <div className="bg-gradient-to-br from-amber-50/90 via-pink-50/40 to-emerald-50/80 border border-amber-200/90 rounded-2xl overflow-hidden shadow-xs p-5 sm:p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-200/70">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center shadow-xs">
                  <Cake className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-extrabold text-neutral-900 tracking-tight flex items-center gap-1.5">
                      <span>{language === 'bn' ? 'চলতি মাসের জন্মদিনের শুভেচ্ছা ও উদযাপন' : 'Upcoming Member Birthdays This Month'}</span>
                      <PartyPopper className="w-4 h-4 text-amber-600 inline" />
                    </h3>
                  </div>
                  <p className="text-xs text-neutral-600 mt-0.5">
                    {language === 'bn'
                      ? `${monthNamesBn[currentMonthNum - 1]} মাসে সমিতির সদস্যদের জন্মদিনের তালিকা ও পারস্পরিক শুভেচ্ছা বিনিময়`
                      : `Celebrate and connect with cooperative members celebrating birthdays in ${monthNamesEn[currentMonthNum - 1]}`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {todaysBirthdays.length > 0 && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-rose-500 text-white text-xs font-extrabold animate-pulse shadow-xs">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? `আজকের জন্মদিন (${toBengaliNumber(todaysBirthdays.length)})` : `Today (${todaysBirthdays.length})`}</span>
                  </span>
                )}
                <span className="text-xs px-3 py-1 rounded-full bg-amber-100 text-amber-900 font-bold border border-amber-300">
                  {language === 'bn' ? `মোট ${toBengaliNumber(birthdayMembers.length)} জন সদস্য` : `${birthdayMembers.length} Members`}
                </span>
              </div>
            </div>

            {/* Special Highlight Banner if there is a birthday TODAY */}
            {todaysBirthdays.length > 0 && (
              <div className="p-4 bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-600 rounded-xl text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="text-2xl animate-bounce">🎉</div>
                  <div>
                    <div className="text-xs uppercase tracking-wider font-extrabold text-rose-100 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'আজকের বিশেষ শুভ জন্মদিন!' : "Today's Special Birthday!"}</span>
                    </div>
                    <div className="text-base font-bold text-white mt-0.5">
                      {todaysBirthdays.map((m) => (language === 'bn' ? m.nameBn : m.nameEn)).join(', ')}
                    </div>
                    <div className="text-xs text-rose-100">
                      {language === 'bn'
                        ? 'সমিতির পক্ষ থেকে উষ্ণ অভিনন্দন ও শুভকামনা জানাই।'
                        : 'Wishing joy, health, and prosperity from all members of the organization.'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {todaysBirthdays.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setWishSentMap((prev) => ({ ...prev, [m.id]: true }));
                      }}
                      className="px-3.5 py-1.5 bg-white text-rose-700 hover:bg-rose-50 rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Heart className={`w-3.5 h-3.5 ${wishSentMap[m.id] ? 'fill-rose-600 text-rose-600' : 'text-rose-600'}`} />
                      <span>{wishSentMap[m.id] ? (language === 'bn' ? 'শুভেচ্ছা পাঠানো হয়েছে' : 'Wished!') : (language === 'bn' ? 'শুভেচ্ছা জানান' : 'Send Birthday Wish')}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {birthdayMembers.length === 0 ? (
              <div className="py-8 text-center text-xs text-neutral-500 font-medium bg-white/70 rounded-xl border border-dashed border-amber-200">
                <Cake className="w-8 h-8 text-amber-300 mx-auto mb-2" />
                <p>{language === 'bn' ? 'চলতি মাসে কোনো সদস্যের জন্মদিন নেই।' : 'No member birthdays in the current month.'}</p>
                <p className="text-[11px] text-neutral-400 mt-1">
                  {language === 'bn' ? 'সদস্য প্রোফাইল হতে জন্মতারিখ হালনাগাদ করুন।' : 'Update member profiles to include dates of birth.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {birthdayMembers.map((member) => {
                  const bMonthName = language === 'bn' ? monthNamesBn[member.birthMonth - 1] : monthNamesEn[member.birthMonth - 1];
                  const dayDisplay = language === 'bn' ? toBengaliNumber(member.birthDay) : member.birthDay;
                  const isWished = wishSentMap[member.id];

                  return (
                    <div
                      key={member.id}
                      className={`relative p-3.5 rounded-xl border transition-all ${
                        member.isToday
                          ? 'bg-gradient-to-r from-rose-50 via-amber-50 to-white border-rose-300 ring-2 ring-rose-400/30 shadow-sm'
                          : member.isPast
                          ? 'bg-white/80 border-neutral-200 opacity-90'
                          : 'bg-white border-amber-200 hover:border-amber-300 shadow-2xs hover:shadow-sm'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className="cursor-pointer"
                          onClick={() => onOpenMemberProfile(member)}
                        >
                          <MemberAvatar member={member} sizeClassName="w-12 h-12 shadow-xs" />
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <h4
                              onClick={() => onOpenMemberProfile(member)}
                              className="font-bold text-xs sm:text-sm text-neutral-900 truncate hover:text-emerald-800 cursor-pointer"
                            >
                              {language === 'bn' ? member.nameBn : member.nameEn}
                            </h4>

                            {member.isToday ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-500 text-white uppercase tracking-wider shrink-0 flex items-center gap-1">
                                <Sparkles className="w-3 h-3" />
                                <span>{language === 'bn' ? 'আজকে' : 'Today'}</span>
                              </span>
                            ) : member.isPast ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-neutral-100 text-neutral-600 shrink-0">
                                {language === 'bn' ? 'পার হয়েছে' : 'Passed'}
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 shrink-0 border border-amber-200">
                                {language === 'bn'
                                  ? `${toBengaliNumber(member.daysRemaining)} দিন বাকি`
                                  : `In ${member.daysRemaining} days`}
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-neutral-600">
                            <span className="font-semibold text-amber-900 flex items-center gap-1">
                              <CalendarDays className="w-3.5 h-3.5 text-amber-600" />
                              <span>{dayDisplay} {bMonthName}</span>
                            </span>
                            {member.turningAge > 0 && (
                              <span className="text-[11px] text-neutral-500 font-medium">
                                ({language === 'bn' ? `${toBengaliNumber(member.turningAge)} বছর পূর্ণ` : `${member.turningAge} yrs`})
                              </span>
                            )}
                            <span className="text-[11px] font-mono text-neutral-400">
                              {member.memberNo}
                            </span>
                          </div>

                          {/* Interactive Engagement Action Buttons */}
                          <div className="mt-2.5 pt-2 border-t border-neutral-100 flex items-center justify-between gap-2">
                            <a
                              href={`tel:${member.phone}`}
                              className="text-[11px] font-semibold text-neutral-600 hover:text-neutral-900 inline-flex items-center gap-1 px-2 py-1 rounded bg-neutral-100 hover:bg-neutral-200 transition-colors"
                              title={member.phone}
                            >
                              <PhoneCall className="w-3 h-3 text-emerald-700" />
                              <span className="font-mono">{member.phone}</span>
                            </a>

                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setWishSentMap((prev) => ({ ...prev, [member.id]: true }));
                                }}
                                className={`text-[11px] font-bold px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                                  isWished
                                    ? 'bg-rose-100 text-rose-800 border border-rose-300'
                                    : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
                                }`}
                              >
                                <Heart className={`w-3 h-3 ${isWished ? 'fill-rose-600 text-rose-600' : 'text-emerald-700'}`} />
                                <span>
                                  {isWished
                                    ? (language === 'bn' ? 'শুভেচ্ছা পাঠানো হয়েছে' : 'Wished')
                                    : (language === 'bn' ? 'শুভেচ্ছা দিন' : 'Send Wish')}
                                </span>
                              </button>

                              <button
                                type="button"
                                onClick={() => onOpenMemberProfile(member)}
                                className="text-[11px] font-semibold text-neutral-700 hover:text-neutral-950 px-2 py-1 rounded hover:bg-neutral-100 transition-colors cursor-pointer"
                              >
                                {language === 'bn' ? 'প্রোফাইল' : 'Profile'}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Quick Collection Strip */}
          <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
            <div className="p-4 sm:p-5 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-base font-bold text-neutral-900">
                    {language === 'bn' ? 'চলতি মাসের কিস্তি কালেকশন শিট' : 'Monthly Kisti Due Status'}
                  </h3>
                  <input
                    type="month"
                    value={selectedDashboardMonth}
                    onChange={(e) => setSelectedDashboardMonth(e.target.value)}
                    className="text-xs font-mono font-bold px-2 py-0.5 border border-neutral-300 rounded bg-white text-neutral-800"
                  />
                </div>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {language === 'bn'
                    ? 'যাদের কিস্তি এখনো জমা হয়নি (১,০০০৳ দ্রুত জমা বা কালেকশন বাটন)'
                    : 'Members pending savings kisti for the selected period'}
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('kisti')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 shrink-0"
              >
                <span>{language === 'bn' ? 'পূর্ণাঙ্গ শিট দেখুন' : 'Full Sheet'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-neutral-200">
              {pendingMembers.length === 0 ? (
                <div className="p-8 text-center text-xs text-emerald-700 font-semibold bg-emerald-50/50">
                  ✓ {language === 'bn' ? 'অভিনন্দন! নির্বাচিত মাসের সকল সদস্যের কিস্তি আদায় সম্পন্ন হয়েছে।' : 'All members have paid their monthly kisti for this month!'}
                </div>
              ) : (
                pendingMembers.slice(0, 5).map((member) => (
                  <div
                    key={member.id}
                    className="p-3.5 sm:px-5 flex items-center justify-between gap-3 hover:bg-neutral-50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <MemberAvatar member={member} sizeClassName="w-9 h-9" />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-neutral-900">
                            {language === 'bn' ? member.nameBn : member.nameEn}
                          </span>
                          <span className="font-mono text-[10px] text-neutral-500">
                            ({member.memberNo})
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-500 font-mono mt-0.5">
                          {member.phone}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="font-mono font-bold text-xs tabular-nums text-neutral-900">
                          {formatCurrency(member.monthlySavingsCommitment, language)}
                        </div>
                        <div className="text-[10px] text-amber-700 font-medium">
                          {language === 'bn' ? 'বকেয়া' : 'Due'}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            onOpenCollectModal(
                              member.id,
                              'savings',
                              selectedDashboardMonth,
                              1000
                            )
                          }
                          title={language === 'bn' ? 'সরাসরি ১,০০০ ৳ কিস্তি জমা নিন' : 'Quick 1,000 BDT'}
                          className="px-2.5 py-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors"
                        >
                          ১,০০০৳
                        </button>
                        <button
                          onClick={() =>
                            onOpenCollectModal(
                              member.id,
                              'savings',
                              selectedDashboardMonth,
                              member.monthlySavingsCommitment || 1000
                            )
                          }
                          className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded-lg transition-colors"
                        >
                          {language === 'bn' ? 'জমা নিন' : 'Collect'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {pendingMembers.length > 5 && (
              <div className="p-3 text-center bg-neutral-50 border-t border-neutral-100 text-xs text-neutral-600 font-medium">
                {language === 'bn'
                  ? `আরও ${toBengaliNumber(pendingMembers.length - 5)} জন সদস্যের কিস্তি বাকি আছে`
                  : `${pendingMembers.length - 5} more members have dues`}
              </div>
            )}
          </div>

          {/* Recent Kisti Receipts Ledger */}
          <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
            <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-neutral-900">
                  {language === 'bn' ? 'সাম্প্রতিক কিস্তির রসিদসমূহ' : 'Recent Kisti Receipts'}
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {language === 'bn' ? 'সরাসরি মানি রসিদ ভিউ ও প্রিন্ট করুন' : 'View and print verified collection receipts'}
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('kisti')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
              >
                <span>{language === 'bn' ? 'সকল লেনদেন' : 'All Transactions'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 text-neutral-600 font-semibold uppercase tracking-wider border-b border-neutral-200">
                  <tr>
                    <th className="py-2.5 px-4"># {language === 'bn' ? 'রসিদ' : 'Receipt'}</th>
                    <th className="py-2.5 px-4">{language === 'bn' ? 'সদস্য' : 'Member'}</th>
                    <th className="py-2.5 px-4">{language === 'bn' ? 'খাত' : 'Type'}</th>
                    <th className="py-2.5 px-4 text-right">{language === 'bn' ? 'পরিমাণ' : 'Amount'}</th>
                    <th className="py-2.5 px-4 text-center">{language === 'bn' ? 'রসিদ' : 'Action'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {recentTransactions.map((tx) => {
                    const mem = members.find((m) => m.id === tx.memberId);
                    return (
                      <tr key={tx.id} className="hover:bg-neutral-50/80 transition-colors">
                        <td className="py-2.5 px-4 font-mono font-medium text-neutral-800">{tx.receiptNo}</td>
                        <td className="py-2.5 px-4 font-semibold text-neutral-900">
                          {language === 'bn' ? mem?.nameBn || mem?.nameEn : mem?.nameEn}
                        </td>
                        <td className="py-2.5 px-4 text-neutral-600">
                          {tx.type === 'savings'
                            ? language === 'bn' ? 'সঞ্চয় কিস্তি' : 'Savings'
                            : tx.type === 'loan_repayment'
                            ? language === 'bn' ? 'ঋণের কিস্তি' : 'Loan Installment'
                            : language === 'bn' ? 'প্রকল্প শেয়ার' : 'Project Share'}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono font-bold tabular-nums text-emerald-700">
                          {formatCurrency(tx.amount, language)}
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          <button
                            onClick={() => onOpenReceipt(tx)}
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 hover:text-emerald-950"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>{language === 'bn' ? 'রসিদ' : 'Print'}</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Projects & Task Activity */}
        <div className="space-y-6">
          {/* Active Investment Projects Card */}
          <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-neutral-900">
                  {language === 'bn' ? 'সমিতির বিনিয়োগ (Investment)' : 'Somiti Investments'}
                </h3>
                <p className="text-[11px] text-emerald-700 font-medium">
                  {language === 'bn' ? 'জমি লিজসহ সক্রিয় বিনিয়োগ ও মুনাফা' : 'Land Lease & Active Investments'}
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('projects_tasks')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
              >
                <span>{language === 'bn' ? 'বিস্তারিত' : 'View'}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-4">
              {projects.map((project) => {
                const capitalPercent = Math.min(
                  100,
                  Math.round((project.collectedCapital / project.targetBudget) * 100)
                );
                const projectTaskCount = tasks.filter((t) => t.projectId === project.id).length;

                return (
                  <div key={project.id} className="p-3 bg-neutral-50 rounded-lg border border-neutral-200">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-mono font-bold text-emerald-800">{project.code}</span>
                      <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded">
                        {project.category === 'agriculture' ? (language === 'bn' ? '🌾 জমি লিজ' : '🌾 Land Lease') : (language === 'bn' ? '💼 বিনিয়োগ' : '💼 Investment')}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-neutral-900 line-clamp-1">
                      {language === 'bn' ? project.titleBn : project.titleEn}
                    </h4>

                    {/* Capital & Profit */}
                    <div className="mt-2.5 flex items-center justify-between text-[11px] bg-white p-2 rounded border border-neutral-200">
                      <div>
                        <span className="text-neutral-500 block text-[10px]">{language === 'bn' ? 'মূলধন:' : 'Capital:'}</span>
                        <strong className="font-mono text-neutral-900">
                          {formatCurrency(project.investedAmount || project.targetBudget, language)}
                        </strong>
                      </div>
                      {project.totalProfit && project.totalProfit > 0 ? (
                        <div className="text-right">
                          <span className="text-emerald-700 block text-[10px] font-semibold">{language === 'bn' ? 'অর্জিত লাভ:' : 'Profit:'}</span>
                          <strong className="font-mono text-emerald-700 font-bold">
                            +{formatCurrency(project.totalProfit, language)}
                          </strong>
                        </div>
                      ) : (
                        <div className="text-right">
                          <span className="text-neutral-500 block text-[10px]">{language === 'bn' ? 'প্রত্যাশিত লাভ:' : 'Expected:'}</span>
                          <span className="font-mono text-neutral-700">{toBengaliNumber(project.expectedReturnPercent || 10)}%</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

            {/* Quick Cashier Vault Snapshot */}
            <div className="bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 text-white rounded-xl p-5 shadow-md border border-blue-800/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wallet className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-200">
                    {language === 'bn' ? 'ক্যাশিয়ার ফান্ড ডেস্ক' : 'Cashier Vault Desk'}
                  </span>
                </div>
                <button
                  onClick={() => onNavigateTab('cashier')}
                  className="text-xs text-blue-300 hover:text-white font-semibold transition cursor-pointer"
                >
                  {language === 'bn' ? 'ক্যাশবুক খতিয়ান' : 'Cashbook'} →
                </button>
              </div>

              <div>
                <div className="text-[11px] text-blue-300/80">
                  {language === 'bn' ? 'আজকের দিনে মোট সংগৃহীত ক্যাশ:' : "Today's Total Cash Collected:"}
                </div>
                <div className="text-xl font-bold font-mono tabular-nums text-emerald-400 mt-0.5">
                  {formatCurrency(cashInHand, language)}
                </div>
              </div>

              <div className="pt-2 border-t border-blue-900/60 text-[11px] text-blue-300/80 flex justify-between">
                <span>{language === 'bn' ? 'ক্যাশিয়ার:' : 'Cashier:'} {cashierMember?.nameEn}</span>
                <span className="text-blue-300 font-semibold">{language === 'bn' ? 'ভল্ট নিরাপদ' : 'Audited'}</span>
              </div>
            </div>
        </div>
      </div>
    </div>
  );
};
