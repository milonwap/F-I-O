/**
 * Central Cloud Database Client for Google AI Studio Shared Links & AI Studio Preview
 * 
 * Provides direct client-side persistent real-time cloud database sync:
 * - JSONBin.io (Hardcoded Master Key & Primary Bin ID: 67ab2d67ad19ca34f861b1be)
 * - Active verified bin fallback (6accd034ac6210605a2a7a27)
 * - LocalStorage robust cached fallback
 *
 * Both the AI Studio Preview environment and Live Public Shared links connect
 * to the exact same authoritative cloud store bidirectionally!
 */

export interface CloudDbConfig {
  provider: 'auto' | 'jsonbin' | 'firestore' | 'custom_api';
  jsonbinApiKey?: string;
  jsonbinBinId?: string;
}

const DEFAULT_CONFIG_KEY = 'somiti_cloud_db_config_v2';
const CLOUD_CACHE_KEY = 'somiti_cloud_db_cached_bundle_v2';

// USER CONFIG: Permanent Hardcoded Master Credentials
export const PRIMARY_BIN_ID = '67ab2d67ad19ca34f861b1be';
export const MASTER_API_KEY = '$2a$10$XERM8C0ABCRZZYEvVPEOIOrNqPDcVJone6Kd/ObkK/jYnMMOba.6.';

// Active bin verified under this Master Key with live somiti data
export const ACTIVE_VERIFIED_BIN_ID = '6accd034ac6210605a2a7a27';

export function getCloudDbConfig(): CloudDbConfig {
  try {
    const raw = localStorage.getItem(DEFAULT_CONFIG_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.jsonbinBinId) return parsed;
    }
  } catch {}
  return {
    provider: 'jsonbin',
    jsonbinBinId: PRIMARY_BIN_ID,
    jsonbinApiKey: MASTER_API_KEY,
  };
}

export function saveCloudDbConfig(cfg: CloudDbConfig) {
  try {
    localStorage.setItem(DEFAULT_CONFIG_KEY, JSON.stringify(cfg));
  } catch {}
}

export interface CloudSyncBundle {
  members: any[];
  transactions: any[];
  loans: any[];
  projects: any[];
  projectExpenses: any[];
  tasks: any[];
  cashbook: any[];
  version: number;
  updatedAt: string;
  updatedBy: string;
}

/**
 * Verify Cloud DB connection status and return diagnostic info
 */
export async function verifyCloudDbConnection(): Promise<{ connected: boolean; message: string; version?: number; membersCount?: number }> {
  try {
    const config = getCloudDbConfig();
    const binIdsToTry = [
      PRIMARY_BIN_ID,
      config.jsonbinBinId,
      ACTIVE_VERIFIED_BIN_ID,
    ].filter(Boolean) as string[];

    const apiKey = config.jsonbinApiKey || MASTER_API_KEY;

    for (const bId of binIdsToTry) {
      try {
        const res = await fetch(`https://api.jsonbin.io/v3/b/${bId}/latest`, {
          method: 'GET',
          headers: {
            'X-Master-Key': apiKey,
            'X-Bin-Meta': 'false',
          },
          cache: 'no-store',
        });

        if (res.ok) {
          const json = await res.json();
          const data = json?.record || json;
          if (data && Array.isArray(data.members)) {
            return {
              connected: true,
              message: 'Cloud DB Connected & Verified (JSONBin.io)',
              version: data.version || 1,
              membersCount: data.members.length,
            };
          }
        }
      } catch {}
    }

    // Try local node endpoint if JSONBin had network timeout
    try {
      const srvRes = await fetch('/api/version');
      if (srvRes.ok) {
        const srvData = await srvRes.json();
        return {
          connected: true,
          message: 'Cloud DB Connected (Local Node Fallback)',
          version: srvData.version || 1,
        };
      }
    } catch {}

    return {
      connected: false,
      message: 'Cloud DB Disconnected or Offline',
    };
  } catch (err: any) {
    return {
      connected: false,
      message: err?.message || 'Connection test failed',
    };
  }
}

/**
 * Fetch authoritative data from Central Cloud DB (JSONBin.io)
 * JSONBin is queried first to bridge AI Studio Preview and Live Shared links authoritatively.
 */
export async function fetchFromCloudDb(): Promise<CloudSyncBundle | null> {
  const config = getCloudDbConfig();
  const binIdsToTry = [
    PRIMARY_BIN_ID,
    config.jsonbinBinId,
    ACTIVE_VERIFIED_BIN_ID,
  ].filter(Boolean) as string[];

  const apiKey = config.jsonbinApiKey || MASTER_API_KEY;

  // 1. Direct JSONBin cloud storage (Authoritative across Preview & Live Shared Link)
  for (const bId of binIdsToTry) {
    try {
      const res = await fetch(`https://api.jsonbin.io/v3/b/${bId}/latest`, {
        method: 'GET',
        headers: {
          'X-Master-Key': apiKey,
          'X-Bin-Meta': 'false',
        },
        cache: 'no-store',
      });

      if (res.ok) {
        const json = await res.json();
        const data = json?.record || json;
        if (data && Array.isArray(data.members)) {
          cacheCloudBundle(data);
          // Also sync to local express server in background if running
          try {
            fetch('/api/data', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(data),
            }).catch(() => {});
          } catch {}
          return data;
        }
      }
    } catch (binErr) {
      console.warn('JSONBin fetch attempt error on bin:', bId, binErr);
    }
  }

  // 2. Fallback to local Express /api/data endpoint if offline from JSONBin
  try {
    const localRes = await fetch('/api/data', { cache: 'no-store' });
    if (localRes.ok) {
      const data = await localRes.json();
      if (data && Array.isArray(data.members)) {
        cacheCloudBundle(data);
        return data;
      }
    }
  } catch {}

  // 3. Fallback to cached bundle
  return getCachedCloudBundle();
}

/**
 * Save authoritative data to Central Cloud DB
 * Pushes to JSONBin.io immediately so changes made in Preview appear in Live link, and vice versa.
 */
export async function pushToCloudDb(bundle: Partial<CloudSyncBundle>): Promise<{ success: boolean; version?: number; error?: string }> {
  // Use cached state for any unspecified fields instead of blocking on an extra remote GET
  const current = getCachedCloudBundle() || {
    members: [],
    transactions: [],
    loans: [],
    projects: [],
    projectExpenses: [],
    tasks: [],
    cashbook: [],
    version: 1,
    updatedAt: new Date().toISOString(),
    updatedBy: 'admin',
  };

  const newVersion = (current.version || 0) + 1;
  const fullBundle: CloudSyncBundle = {
    members: bundle.members ?? current.members,
    transactions: bundle.transactions ?? current.transactions,
    loans: bundle.loans ?? current.loans,
    projects: bundle.projects ?? current.projects,
    projectExpenses: bundle.projectExpenses ?? current.projectExpenses,
    tasks: bundle.tasks ?? current.tasks,
    cashbook: bundle.cashbook ?? current.cashbook,
    version: newVersion,
    updatedAt: new Date().toISOString(),
    updatedBy: bundle.updatedBy || 'admin',
  };

  // Cache locally immediately
  cacheCloudBundle(fullBundle);

  let pushedSuccessfully = false;
  let pushError: string | undefined = undefined;

  // 1. Direct JSONBin cloud storage push
  const config = getCloudDbConfig();
  const binIdsToTry = [
    PRIMARY_BIN_ID,
    config.jsonbinBinId,
    ACTIVE_VERIFIED_BIN_ID,
  ].filter(Boolean) as string[];

  const apiKey = config.jsonbinApiKey || MASTER_API_KEY;

  for (const bId of binIdsToTry) {
    try {
      const res = await fetch(`https://api.jsonbin.io/v3/b/${bId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': apiKey,
        },
        body: JSON.stringify(fullBundle),
      });
      if (res.ok) {
        pushedSuccessfully = true;
        break;
      } else {
        const errText = await res.text();
        pushError = `JSONBin Error (${res.status}): ${errText}`;
      }
    } catch (binErr: any) {
      console.warn('Direct cloud DB push error on bin:', bId, binErr);
      pushError = binErr?.message || 'Network error connecting to JSONBin.io';
    }
  }

  // 2. Also save to local server endpoint if alive
  try {
    const res = await fetch('/api/data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fullBundle),
    });
    if (res.ok) {
      pushedSuccessfully = true;
    }
  } catch {}

  return {
    success: pushedSuccessfully,
    version: newVersion,
    error: pushedSuccessfully ? undefined : (pushError || 'ক্লাউড সেভ ব্যর্থ হয়েছে, ইন্টারনেট বা কি যাচাই করুন'),
  };
}

/**
 * Direct Member Credential updater (User ID & Password) in Cloud DB
 */
export async function updateCredentialsInCloudDb(
  memberId: string,
  newMemberNo?: string,
  newPassword?: string,
  updatedBy: string = 'admin'
): Promise<{ success: boolean; error?: string; updatedMember?: any }> {
  try {
    // Load latest cloud data
    const bundle = (await fetchFromCloudDb()) || getCachedCloudBundle();
    if (!bundle || !Array.isArray(bundle.members)) {
      return { success: false, error: 'Could not connect to central database' };
    }

    const cleanMemberNo = newMemberNo?.trim().toUpperCase();
    const cleanPass = newPassword?.trim();

    let targetFound = false;
    let updatedMember: any = null;

    const updatedMembers = bundle.members.map((m: any) => {
      if (m.id === memberId || m.memberNo === memberId) {
        targetFound = true;
        updatedMember = {
          ...m,
          memberNo: cleanMemberNo || m.memberNo,
          password: cleanPass || m.password,
        };
        return updatedMember;
      }
      return m;
    });

    if (!targetFound) {
      return { success: false, error: 'Member not found in central database' };
    }

    // Push full updated bundle back to cloud
    const saveRes = await pushToCloudDb({
      members: updatedMembers,
      updatedBy,
    });

    return { success: saveRes.success, error: saveRes.error, updatedMember };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error updating credentials in cloud database' };
  }
}

/**
 * Direct Member Profile updater (Nominee, Phone, Photo, Address) in Cloud DB
 */
export async function updateMemberProfileInCloudDb(
  memberId: string,
  profileUpdates: Record<string, any>,
  updatedBy: string = 'member'
): Promise<{ success: boolean; error?: string; updatedMember?: any }> {
  try {
    const bundle = (await fetchFromCloudDb()) || getCachedCloudBundle();
    if (!bundle || !Array.isArray(bundle.members)) {
      return { success: false, error: 'Could not connect to central database' };
    }

    let targetFound = false;
    let updatedMember: any = null;

    const updatedMembers = bundle.members.map((m: any) => {
      if (m.id === memberId || m.memberNo === memberId) {
        targetFound = true;
        updatedMember = {
          ...m,
          ...profileUpdates,
        };
        return updatedMember;
      }
      return m;
    });

    if (!targetFound) {
      return { success: false, error: 'Member not found in central database' };
    }

    const saveRes = await pushToCloudDb({
      members: updatedMembers,
      updatedBy,
    });

    return { success: saveRes.success, error: saveRes.error, updatedMember };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error updating profile in cloud database' };
  }
}

function cacheCloudBundle(bundle: CloudSyncBundle) {
  try {
    localStorage.setItem(CLOUD_CACHE_KEY, JSON.stringify(bundle));
  } catch {}
}

function getCachedCloudBundle(): CloudSyncBundle | null {
  try {
    const raw = localStorage.getItem(CLOUD_CACHE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}
